--Mercier Tony
--Jones Marie

--TP3 : L-Systeme et Tortue

import Graphics.Gloss
import Data.List


dessin = interpreteMot (((-150,0),0),100,1,pi/3,"F+-") "F+F--F+F"
main = display (InWindow "L-système" (1000, 1000) (0, 0)) white dessin

--Partie 1 : implémentation

type Symbole  = Char
type Mot      = [Symbole]
type Axiome   = Mot
type Regles   = Symbole -> Mot
type LSysteme = [Mot]

--Q1 :

--version recursive
motSuivantRec::Regles->Mot->Mot
motSuivantRec r uns =
  if uns == []
    then []
    else r (head uns) ++ (motSuivantRec r (tail uns))

--version avec liste de compréhension
motSuivantComprehension::Regles->Mot->Mot
motSuivantComprehension r uns = concat ([r x | x <-uns ])

--version avec une fonction du prelude
motSuivantAvecPrelude::Regles->Mot->Mot
motSuivantAvecPrelude r uns =
  concat (map r uns)

--Q2 :
vonKoch = ['-','+','F']

axiomeVonKoch = last vonKoch : []

reglesVonKoch::Symbole->Mot
reglesVonKoch s | s == '-' = ['-']
                | s == '+' = ['+']
                | s == 'F' = ['F','-','F','+','+','F','-','F']

--Q3 :
lsysteme::Axiome->Regles->LSysteme
lsysteme ms r =
  iterate (motSuivantAvecPrelude r) ms

--Partie 2 : La tortue

type EtatTortue = (Point,Float)
type Config     = (EtatTortue,Float,Float,Float,[Symbole])

--Q4 :
etatInitial::Config->EtatTortue
etatInitial (e,_,_,_,_) = e

longueurPas::Config->Float
longueurPas (_,p,_,_,_) = p

facteurEchelle::Config->Float
facteurEchelle (_,_,f,_,_) = f

angle::Config->Float
angle (_,_,_,a,_) = a

symbolesTortue::Config->[Symbole]
symbolesTortue (_,_,_,_,ss) = ss

--Q5 :
avance::Config->EtatTortue->EtatTortue
avance config etat =
  ((x + d*(cos cap), y+ d*(sin cap)),cap)
    where x   = fst (fst etat)
          y   = snd (fst etat)
          cap = snd etat
          d   = longueurPas config

--Q6 :
tourneAGauche::Config->EtatTortue->EtatTortue
tourneAGauche config etat =
  (fst etat,cap + alpha )
    where alpha = angle config
          cap   = snd etat

tourneADroite::Config->EtatTortue->EtatTortue
tourneADroite config etat =
  (fst etat, cap -alpha )
    where alpha = angle config
          cap = snd etat

--Q7 :
filtresSymbolesTortue::Config->Mot->Mot
filtresSymbolesTortue config (s:mots) | (intersect [s] symboles) == [] = filtresSymbolesTortue mots
                                    | otherwise                      = s:filtresSymbolesTortue mots
                                      where symboles = symbolesTortue config

type EtatDessin = (EtatTortue,Path)

--Q8 :
interpreteSymbole::Config->EtatDessin->Symbole->EtatDessin

interpreteSymbole config ed s | s == 'F'  = (avance config et,nouveauDessin)
                              | s == '-'  = (tourneADroite config et,nouveauDessin)
                              | s == '+'  = (tourneAGauche config et,nouveauDessin)
                              | otherwise = error "This symbol is not correct"
                                where et = etatInitial config
                                      nouveauDessin = snd ed ++ [fst et]

--Q9 :
interpreteMot::Config->Mot->Picture

interpreteMot config mots =
  line (snd (go config valides (et,[])))
    where et                  = etatInitial config
          go config (l:mots) ed = go config mots (interpreteSymbole config ed l)
          valides               = filtresSymbolesTortue config mots


--Q10 :
--lsystemeAnime::LSysteme->Config->Float->Picture

--lsystemeAnime lsys config t =
