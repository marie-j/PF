Jones Marie
Mercier Tony

Readme - TP5 Interpète

L'interprète parallèle n'est pas fonctionnel, il met d'ailleurs plus de temps que l'interprète monadique standard pour fibonacci.interp.

Pour créer un éxécutable , il suffit de taper make puis de lancer l'interprète à l'iade de ./interprete
