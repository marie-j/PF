Mercier Tony
Jones Marie

Readme - TP4 : Arbres

Vous trouverez dans cette archive :
  - un fichier source arbres.hs contenant l'intégralité de notre code
  - un fichier arbre.dot et un fichier arbre2.dot représentant respectivement les résultats obtenus en lançant "runghc arbres.hs" respectivement
avec arbreDot et arbreDot' (le second utilisant une fonction de comparaison)
  - un fichier arbre.png et un fichier arbre2.png contenant respectivant les images correspondantes aux fichier .dot
